# 0.3.0
- Add extension trait interface.

# 0.2.2
- Fix panic or undesired behavior when dealing with non-ASCII input.

# 0.2.1
- Minor optimization of `unix2dos`.

# 0.2.0
- Changed `dos2unix` and `unix2dos` functions to accept `AsRef<str>` as input.