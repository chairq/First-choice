#![allow(clippy::needless_lifetimes)]

mod regression {
    automod::dir!("tests/regression");
}
