use crate::CustomTypePromptAction;

/// Set of actions for a ConfirmPrompt.
pub type ConfirmPromptAction = CustomTypePromptAction;
